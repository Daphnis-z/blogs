package com.daphnis.network.server;

import com.daphnis.network.util.CommonUtil;
import com.daphnis.network.util.DBUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AlarmSerialTask implements Runnable {

  private static Logger LOG = LoggerFactory.getLogger(AlarmSerialTask.class);

  @Override
  public void run() {
    // 为新产生的告警生成编号
    // 启动时默认为 2分钟内产生的告警生成编号
    long lastTime = System.currentTimeMillis() - CommonUtil.minute2Mills(2);

    while (true) {
      try {
        long endMills = System.currentTimeMillis();

        String startTime = CommonUtil.formatTimeMills(lastTime);
        String endTime = CommonUtil.formatTimeMills(endMills);
        int alarmCount = DBUtil.geneAlarmSerial(startTime, endTime);
        LOG.info(
            String.format("[%s,%s) generate %s alarm serials..", startTime, endTime, alarmCount));

        lastTime = endMills;
        Thread.sleep(30000);
      } catch (Exception e) {
        LOG.error("generate alarm serial error !!", e);
      }
    }
  }

}
