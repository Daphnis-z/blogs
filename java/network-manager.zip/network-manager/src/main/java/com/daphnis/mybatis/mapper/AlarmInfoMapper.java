package com.daphnis.mybatis.mapper;

import com.daphnis.mybatis.entity.AlarmInfo;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AlarmInfoMapper {

  List<AlarmInfo> selectSomeAlarmInfo(@Param("startTime") String startTime,
      @Param("endTime") String endTime);

  List<AlarmInfo> selectAlarmInfoByMsgSerial(@Param("startTime") String startTime,
      @Param("endTime") String endTime, @Param("msgSerial") String msgSerial);

  int updateAlarmSendStatus(@Param("clearKeywords") List<String> clearKeywords);
}
