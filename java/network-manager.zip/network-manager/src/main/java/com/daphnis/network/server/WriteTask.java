package com.daphnis.network.server;

import com.daphnis.mybatis.entity.AlarmInfo;
import java.util.List;

public class WriteTask {

  private String taskName;
  private List<String> messages;
  private List<AlarmInfo> alarmInfos;

  public WriteTask(String taskName, List<String> messages) {
    this.taskName = taskName;
    this.messages = messages;
  }

  public WriteTask(String taskName, List<String> messages,
      List<AlarmInfo> alarmInfos) {
    this.taskName = taskName;
    this.messages = messages;
    this.alarmInfos = alarmInfos;
  }

  public String getTaskName() {
    return taskName;
  }

  public List<String> getMessages() {
    return messages;
  }

  public List<AlarmInfo> getAlarmInfos() {
    return alarmInfos;
  }

  @Override
  public String toString() {
    return String.format("[task name: %s,messages count: %s]", taskName, messages.size());
  }
}
