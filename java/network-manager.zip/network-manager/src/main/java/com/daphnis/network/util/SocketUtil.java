package com.daphnis.network.util;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

public class SocketUtil {

  /**
   * 从 Socket 读取单条消息
   *
   * @param socket
   * @return
   */
  public static String readMessage(Socket socket) {
    try (DataInputStream inStream = new DataInputStream(socket.getInputStream())) {
      return inStream.readUTF();
    } catch (Exception e) {
      e.printStackTrace();
    }

    return "";
  }

  /**
   * 往 Socket 写入单条消息
   *
   * @param msg
   * @param socket
   */
  public static void writeMessage(String msg, Socket socket) {
    try (DataOutputStream outStream = new DataOutputStream(socket.getOutputStream())) {
      outStream.writeUTF(msg);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}
