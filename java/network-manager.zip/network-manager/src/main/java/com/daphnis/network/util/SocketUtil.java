package com.daphnis.network.util;

import com.daphnis.mybatis.entity.AlarmInfo;
import com.daphnis.mybatis.mapper.AlarmInfoMapper;
import com.daphnis.network.protocol.BaseProtocol;
import com.daphnis.network.protocol.HeartbeatProtocol;
import com.daphnis.network.protocol.LoginProtocol;
import com.daphnis.network.protocol.ResendProtocol;
import com.google.common.collect.Lists;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.session.SqlSession;

public class SocketUtil {

  private static Map<String, String> msgType2ClassName = new HashMap<>();
  private static final String PKG_NAME = "com.daphnis.network.protocol";

  static {
    msgType2ClassName.put(LoginProtocol.MSG_TYPE, PKG_NAME + ".LoginProtocol");
    msgType2ClassName.put(HeartbeatProtocol.MSG_TYPE, PKG_NAME + ".HeartbeatProtocol");
    msgType2ClassName.put(ResendProtocol.MSG_TYPE, PKG_NAME + ".ResendProtocol");
  }


  /**
   * 从 Socket流 读取单条消息
   *
   * @param inStream
   * @return
   */
  public static BaseProtocol readMessageFromStream(DataInputStream inStream)
      throws IOException {
    String msg = inStream.readUTF();
    String msgType = BaseProtocol.getMessageType(msg);

    if (msgType2ClassName.containsKey(msgType)) {
      String className = msgType2ClassName.get(msgType);
      try {
        BaseProtocol baseProtocol = (BaseProtocol) Class.forName(className).newInstance();
        baseProtocol.analysisMessage(msg);
        return baseProtocol;
      } catch (Exception e) {
        e.printStackTrace();
      }
    }

    return new BaseProtocol();
  }

  /**
   * 往 Socket流 写入单条消息
   *
   * @param message
   * @param outStream
   * @throws IOException
   */
  public static void writeMessage2Stream(String message, DataOutputStream outStream)
      throws IOException {
    outStream.writeUTF(message);
  }

  /**
   * 往 Socket流 写入多条消息
   *
   * @param messages
   * @param outStream
   * @throws IOException
   */
  public static void writeMessageList2Stream(List<String> messages, DataOutputStream outStream)
      throws IOException {
    for (String message : messages) {
      outStream.writeUTF(message);
    }
  }


  /**
   * 将指定时间内产生的告警信息推送到客户端
   *
   * @param startTime
   * @param endTime
   * @param outStream
   * @return 发送的告警数量
   * @throws IOException
   */
  public static int sendAlarm2Client(String startTime, String endTime,
      DataOutputStream outStream) throws IOException {
    System.out
        .println(String.format("send time: [%s,%s) alarm message to client..", startTime, endTime));

    try (SqlSession sqlSession = DBUtil.openSession()) {
      AlarmInfoMapper alarmInfoMapper = sqlSession.getMapper(AlarmInfoMapper.class);
      List<AlarmInfo> alarmInfos = alarmInfoMapper.selectSomeAlarmInfo(startTime, endTime);
      List<String> clearKeywords = Lists.newArrayList();
      for (AlarmInfo alarmInfo : alarmInfos) {
        outStream.writeUTF(ProtocolUtil.createAlarmMsg(alarmInfo));
        clearKeywords.add(alarmInfo.getClearKeyword());
      }

      // 告警信息成功推送后将数据库中 发送状态字段 设置为 已发送
      if (!clearKeywords.isEmpty()) {
        int msgCount = alarmInfoMapper.updateAlarmSendStatus(clearKeywords);
        sqlSession.commit();

        return msgCount;
      }
    }

    return 0;
  }

}
