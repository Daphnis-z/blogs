package com.daphnis.network.util;

import com.daphnis.mybatis.entity.AlarmInfo;
import com.daphnis.mybatis.mapper.AlarmInfoMapper;
import com.google.common.collect.Lists;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.List;
import org.apache.ibatis.session.SqlSession;

public class SocketUtil {

  /**
   * 从 Socket 读取单条消息
   *
   * @param socket
   * @return
   */
  public static String readMessage(Socket socket) {
    try (DataInputStream inStream = new DataInputStream(socket.getInputStream())) {
      return inStream.readUTF();
    } catch (Exception e) {
      e.printStackTrace();
    }

    return "";
  }

  /**
   * 往 Socket 写入单条消息
   *
   * @param msg
   * @param socket
   */
  public static void writeMessage(String msg, Socket socket) {
    try (DataOutputStream outStream = new DataOutputStream(socket.getOutputStream())) {
      outStream.writeUTF(msg);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * 将指定时间内产生的告警信息推送到客户端
   *
   * @param startTime
   * @param endTime
   * @param outStream
   * @return 发送的告警数量
   * @throws IOException
   */
  public static int sendAlarm2Client(String startTime, String endTime,
      DataOutputStream outStream) throws IOException {
    System.out
        .println(String.format("send time: [%s,%s) alarm message to client..", startTime, endTime));

    try (SqlSession sqlSession = DBUtil.openSession()) {
      AlarmInfoMapper alarmInfoMapper = sqlSession.getMapper(AlarmInfoMapper.class);
      List<AlarmInfo> alarmInfos = alarmInfoMapper.selectSomeAlarmInfo(startTime, endTime);
      List<String> clearKeywords = Lists.newArrayList();
      for (AlarmInfo alarmInfo : alarmInfos) {
        outStream.writeUTF(ProtocolUtil.createAlarmMsg(alarmInfo));
        clearKeywords.add(alarmInfo.getClearKeyword());
      }

      // 告警信息成功推送后将数据库中 发送状态字段 设置为 已发送
      if (!clearKeywords.isEmpty()) {
        int msgCount = alarmInfoMapper.updateAlarmSendStatus(clearKeywords);
        sqlSession.commit();

        return msgCount;
      }
    }

    return 0;
  }

}
