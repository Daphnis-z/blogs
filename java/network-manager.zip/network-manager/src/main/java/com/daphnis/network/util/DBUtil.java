package com.daphnis.network.util;

import com.daphnis.mybatis.entity.Account;
import com.daphnis.mybatis.entity.AlarmClient;
import com.daphnis.mybatis.entity.AlarmInfo;
import com.daphnis.mybatis.entity.AlarmStatus;
import com.daphnis.mybatis.entity.ClientInfo;
import com.daphnis.mybatis.mapper.AccountMapper;
import com.daphnis.mybatis.mapper.AlarmInfoMapper;
import com.daphnis.mybatis.mapper.ClientInfoMapper;
import com.google.common.collect.Lists;
import java.io.Reader;
import java.util.List;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DBUtil {

  private static Logger LOG = LoggerFactory.getLogger(DBUtil.class);

  private static final String ENV = "oracle";

  private static SqlSessionFactory sqlSessionFactory;

  static {
    try (Reader reader = Resources.getResourceAsReader("mybatis-config.xml")) {
      sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader, ENV);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static SqlSession openSession() {
    return sqlSessionFactory.openSession();
  }

  /**
   * 处理（新增或更新）客户端信息
   *
   * @param clientAddress
   * @return 是否新客户端
   */
  public static boolean handleClientInfo(String clientAddress, Account account) {
    boolean isNewClient = true;
    try (SqlSession sqlSession = openSession()) {
      ClientInfoMapper clientMapper = sqlSession.getMapper(ClientInfoMapper.class);
      ClientInfo clientInfo = clientMapper.selectOneClientInfo(clientAddress);

      ClientInfo newClient = new ClientInfo(clientAddress, account.getUserId());
      newClient.setLoginTime(CommonUtil.getCurrentStdDateTime());
      if (clientInfo == null) {
        // 这是一个新的客户端，缓存客户端信息
        clientMapper.insertOneClientInfo(newClient);
      } else {
        isNewClient = false;
        // 更新客户端的登录时间
        clientMapper.updateClientLogin(newClient);
      }
      sqlSession.commit();
    } catch (Exception e) {
      e.printStackTrace();
    }

    return isNewClient;
  }

  /**
   * 客户端退出，需要更新退出时间
   *
   * @param clientAddress
   * @param account
   * @return
   */
  public static int clientLogout(String clientAddress, Account account) {
    try (SqlSession sqlSession = openSession()) {
      ClientInfoMapper clientMapper = sqlSession.getMapper(ClientInfoMapper.class);

      ClientInfo clientInfo = new ClientInfo(clientAddress, account.getUserId());
      clientInfo.setLogoutTime(CommonUtil.getCurrentStdDateTime());

      int result = clientMapper.updateClientLogout(clientInfo);
      sqlSession.commit();

      return result;
    } catch (Exception e) {
      e.printStackTrace();
    }

    return 0;
  }


  /**
   * 从数据库中查询账户信息
   *
   * @param userName
   * @return
   */
  public static Account queryAccount(String userName) {
    try (SqlSession sqlSession = openSession()) {
      AccountMapper accountMapper = sqlSession.getMapper(AccountMapper.class);
      return accountMapper.selectOneAccount(userName);
    } catch (Exception e) {
      LOG.error("query account from db error !!", e);
    }

    return new Account();
  }

  /**
   * 为指定时间内的告警生成编号
   *
   * @param startTime
   * @param endTime
   * @return
   */
  public static int geneAlarmSerial(String startTime, String endTime) {
    try (SqlSession sqlSession = openSession()) {
      AlarmInfoMapper alarmInfoMapper = sqlSession.getMapper(AlarmInfoMapper.class);
      List<AlarmInfo> alarmInfos = alarmInfoMapper.selectNewAlarmInfo(startTime, endTime);

      if (!alarmInfos.isEmpty()) {
        // 计算 msgSerial 起始位置
        String curDate = CommonUtil.getCurrentShortDate();
        int alarmCount = alarmInfoMapper.countAlarmInfoDay(curDate + "-%");

        // 计算和存储 msgSerial 数据
        List<AlarmStatus> alarmStatuses = Lists.newArrayList();
        for (AlarmInfo alarmInfo : alarmInfos) {
          ++alarmCount;
          alarmInfoMapper.insertOneAlarmStatus(
              new AlarmStatus(curDate + "-" + alarmCount, alarmInfo.getCleared(),
                  alarmInfo.getClearKeyword()));
        }

        sqlSession.commit();
      }

      return alarmInfos.size();
    } catch (Exception e) {
      LOG.error("generate db alarm serial error !!", e);
    }

    return 0;
  }

  /**
   * 查询指定时间内产生的告警
   *
   * @param startTime
   * @param endTime
   * @return
   */
  public static List<AlarmInfo> queryAlarmInfo(String startTime, String endTime) {
    try (SqlSession sqlSession = openSession()) {
      AlarmInfoMapper alarmInfoMapper = sqlSession.getMapper(AlarmInfoMapper.class);
      List<AlarmInfo> alarmInfos = alarmInfoMapper.selectSomeAlarmInfo(startTime, endTime);

      return alarmInfos;
    } catch (Exception e) {
      LOG.error("query alarm info from db error !!", e);
    }

    return Lists.newArrayList();
  }

  /**
   * 查询指定时间内、消息序号后 产生的告警
   *
   * @param startTime
   * @param endTime
   * @return
   */
  public static List<AlarmInfo> queryAlarmInfoByTimeSerial(String startTime, String endTime,
      String msgSerial) {
    try (SqlSession sqlSession = openSession()) {
      AlarmInfoMapper alarmInfoMapper = sqlSession.getMapper(AlarmInfoMapper.class);
      return alarmInfoMapper.selectAlarmInfoByMsgSerial(startTime, endTime, msgSerial);
    } catch (Exception e) {
      LOG.error("query alarm info by time and message serial from db error !!", e);
    }

    return Lists.newArrayList();
  }

  /**
   * 查询指定设备名（可选） 时间内产生的告警
   *
   * @param startTime
   * @param endTime
   * @return
   */
  public static List<AlarmInfo> queryAlarmInfoByNeName(String startTime, String endTime,
      String neName) {
    try (SqlSession sqlSession = openSession()) {
      AlarmInfoMapper alarmInfoMapper = sqlSession.getMapper(AlarmInfoMapper.class);
      return alarmInfoMapper.selectAlarmInfoByNeName(startTime, endTime, neName);
    } catch (Exception e) {
      LOG.error("query alarm info by time and neName from db error !!", e);
    }

    return Lists.newArrayList();
  }

  /**
   * 更新数据库中告警的发送状态
   *
   * @param alarmInfos
   * @return
   */
  public static int updateAlarmSendStatus(List<AlarmInfo> alarmInfos) {
    try (SqlSession sqlSession = openSession()) {
      List<String> clearKeywords = Lists.newArrayList();
      for (AlarmInfo alarmInfo : alarmInfos) {
        clearKeywords.add(alarmInfo.getClearKeyword());
      }

      AlarmInfoMapper alarmInfoMapper = sqlSession.getMapper(AlarmInfoMapper.class);
      int msgCount = alarmInfoMapper.updateAlarmSendStatus(clearKeywords);
      sqlSession.commit();

      return msgCount;
    } catch (Exception e) {
      LOG.error("update db alarm status error !!", e);
    }

    return 0;
  }

  /**
   * 把告警的推送信息存到数据库
   *
   * @param alarmInfos
   * @param clientAddress
   * @return
   */
  public static int insertAlarmClient(List<AlarmInfo> alarmInfos, String clientAddress) {
    try (SqlSession sqlSession = openSession()) {
      AlarmInfoMapper alarmInfoMapper = sqlSession.getMapper(AlarmInfoMapper.class);

      String curStdDateTime = CommonUtil.getCurrentStdDateTime();
      for (AlarmInfo alarmInfo : alarmInfos) {
        AlarmClient alarmClient = new AlarmClient(alarmInfo.getClearKeyword(), clientAddress,
            alarmInfo.getCleared(),
            curStdDateTime);
        alarmInfoMapper.insertOneAlarmClient(alarmClient);
      }

      sqlSession.commit();
      return alarmInfos.size();
    } catch (Exception e) {
      LOG.error("insert alarm client list to db error !!", e);
    }

    return 0;
  }

}
