package com.daphnis.network.util;

import com.daphnis.mybatis.entity.Account;
import com.daphnis.mybatis.entity.AlarmInfo;
import com.daphnis.mybatis.entity.ClientInfo;
import com.daphnis.mybatis.mapper.AccountMapper;
import com.daphnis.mybatis.mapper.AlarmInfoMapper;
import com.daphnis.mybatis.mapper.ClientInfoMapper;
import com.google.common.collect.Lists;
import java.io.Reader;
import java.util.List;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DBUtil {

  private static Logger LOG = LoggerFactory.getLogger(DBUtil.class);

  private static final String ENV = "oracle";

  private static SqlSessionFactory sqlSessionFactory;

  static {
    try (Reader reader = Resources.getResourceAsReader("mybatis-config.xml")) {
      sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader, ENV);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static SqlSession openSession() {
    return sqlSessionFactory.openSession();
  }

  /**
   * 处理（新增或更新）客户端信息
   *
   * @param clientAddress
   * @return 是否新客户端
   */
  public static boolean handleClientInfo(String clientAddress) {
    boolean isNewClient = true;
    try (SqlSession sqlSession = openSession()) {
      ClientInfoMapper clientMapper = sqlSession.getMapper(ClientInfoMapper.class);
      ClientInfo clientInfo = clientMapper.selectOneClientInfo(clientAddress);

      if (clientInfo == null) {
        // 这是一个新的客户端，缓存客户端信息
        clientMapper
            .insertOneClientInfo(new ClientInfo(clientAddress, CommonUtil.getCurrentStdDateTime()));
      } else {
        isNewClient = false;
        // 更新客户端的登录时间
        clientMapper
            .updateClientInfo(new ClientInfo(clientAddress, CommonUtil.getCurrentStdDateTime()));
      }
      sqlSession.commit();
    } catch (Exception e) {
      e.printStackTrace();
    }

    return isNewClient;
  }

  /**
   * 从数据库中查询账户信息
   *
   * @param userName
   * @return
   */
  public static Account queryAccount(String userName) {
    try (SqlSession sqlSession = openSession()) {
      AccountMapper accountMapper = sqlSession.getMapper(AccountMapper.class);
      return accountMapper.selectOneAccount(userName);
    } catch (Exception e) {
      LOG.error("query account from db error !!", e);
    }

    return new Account();
  }

  /**
   * 查询指定时间内产生的告警
   *
   * @param startTime
   * @param endTime
   * @return
   */
  public static List<AlarmInfo> queryAlarmInfo(String startTime, String endTime) {
    try (SqlSession sqlSession = openSession()) {
      AlarmInfoMapper alarmInfoMapper = sqlSession.getMapper(AlarmInfoMapper.class);
      return alarmInfoMapper.selectSomeAlarmInfo(startTime, endTime);
    } catch (Exception e) {
      LOG.error("query alarm info from db error !!", e);
    }

    return Lists.newArrayList();
  }

  /**
   * 更新数据库中告警的发送状态
   *
   * @param clearKeywords
   * @return
   */
  public static int updateAlarmSendStatus(List<String> clearKeywords) {
    try (SqlSession sqlSession = openSession()) {
      AlarmInfoMapper alarmInfoMapper = sqlSession.getMapper(AlarmInfoMapper.class);
      int msgCount = alarmInfoMapper.updateAlarmSendStatus(clearKeywords);
      sqlSession.commit();

      return msgCount;
    } catch (Exception e) {
      LOG.error("update db alarm status error !!", e);
    }

    return 0;
  }
}
