package com.daphnis.network.util;

import com.daphnis.mybatis.entity.ClientInfo;
import com.daphnis.mybatis.mapper.ClientInfoMapper;
import java.io.Reader;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class DBUtil {

  private static final String ENV = "oracle";

  private static SqlSessionFactory sqlSessionFactory;

  static {
    try (Reader reader = Resources.getResourceAsReader("mybatis-config.xml")) {
      sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader, ENV);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public static SqlSession openSession() {
    return sqlSessionFactory.openSession();
  }

  /**
   * 处理（新增或更新）客户端信息
   *
   * @param clientAddress
   * @return 是否新客户端
   */
  public static boolean handleClientInfo(String clientAddress) {
    boolean isNewClient = true;
    try (SqlSession sqlSession = openSession()) {
      ClientInfoMapper clientMapper = sqlSession.getMapper(ClientInfoMapper.class);
      ClientInfo clientInfo = clientMapper.selectOneClientInfo(clientAddress);

      if (clientInfo == null) {
        // 这是一个新的客户端，缓存客户端信息
        clientMapper
            .insertOneClientInfo(new ClientInfo(clientAddress, CommonUtil.getCurrentStdDateTime()));
      } else {
        isNewClient = false;
        // 更新客户端的登录时间
        clientMapper
            .updateClientInfo(new ClientInfo(clientAddress, CommonUtil.getCurrentStdDateTime()));
      }
      sqlSession.commit();
    } catch (Exception e) {
      e.printStackTrace();
    }

    return isNewClient;
  }

}
