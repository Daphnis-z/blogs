package com.daphnis.network;

import com.daphnis.network.server.NetworkServer;
import com.daphnis.network.server.WSAlarmInfo;

public class NetworkServerMain {

  public static void main(String[] args) {
    WSAlarmInfo.start();

    NetworkServer netServer = new NetworkServer();
    netServer.start();
  }

}
