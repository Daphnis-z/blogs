package com.daphnis.network.protocol;

public class HeartbeatProtocol extends BaseProtocol {

  public static final String MSG_TYPE = "ITE-HEARTACK";

}
