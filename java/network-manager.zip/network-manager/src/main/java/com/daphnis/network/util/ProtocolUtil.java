package com.daphnis.network.util;

public class ProtocolUtil {

  /**
   * 创建登录结果应答消息
   *
   * @param validateResult
   * @param faultReason
   * @return
   */
  public static String createLoginResp(boolean validateResult, String faultReason) {
    // ITE-CONNECTACK||VerifyResult=0,FaultReason=
    // 0:成功，1:失败
    return String.format("ITE-CONNECTACK||VerifyResult=%s,FaultReason=%s",
        validateResult ? 0 : 1, faultReason);
  }

}
