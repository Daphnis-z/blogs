package com.daphnis.network.util;

import com.daphnis.mybatis.entity.AlarmInfo;
import com.google.common.base.Strings;

public class ProtocolUtil {

  /**
   * 创建登录结果应答消息
   *
   * @param validateResult
   * @param faultReason
   * @return
   */
  public static String createLoginResp(boolean validateResult, String faultReason) {
    // ITE-CONNECTACK||VerifyResult=0,FaultReason=
    // 0:成功，1:失败
    return String.format("ITE-CONNECTACK||VerifyResult=%s,FaultReason=%s",
        validateResult ? 0 : 1, faultReason);
  }

  /**
   * 创建服务端发送给客户端的心跳消息
   *
   * @param alarmCount 心跳周期内发送的告警条数
   * @return
   */
  public static String createHeartMsg(int alarmCount) {
    return String.format("ITE-HEART||alarmNum=%s,alarmSn=%s", alarmCount,
        CommonUtil.getCurrentShortDateTime());
  }

  /**
   * 按协议生成告警消息
   *
   * @param alarmInfo
   * @return
   */
  public static String createAlarmMsg(AlarmInfo alarmInfo) {
    // ITE-View||msgSerial=20190618-1,cleared=0,clearKeyword=279786023,type=EQUIPMENT,
    // level=WARNING,raiseTime=2014-03-27 17:30:29,clearTime=,neType=PORT,
    // cause=R_LOS,probableCause=R_LOS,neId=0000000000000066474,neName=设备名,subNetName=三区局,
    // vendorId=华为,alarmText=

    // 对 cleared 进行转换，0：新增，1：清除
    String cleared = "0".equals(alarmInfo.getCleared()) ? "新增" : "清除";

    String clearTime =
        Strings.isNullOrEmpty(alarmInfo.getClearTime()) ? "" : alarmInfo.getClearTime();

    return String.format("ITE-View||msgSerial=%s,cleared=%s,clearKeyword=%s,type=%s,"
            + "level=%s,raiseTime=%s,clearTime=%s,neType=%s,cause=%s,probableCause=%s,"
            + "neId=%s,neName=%s,subNetName=%s,vendorId=%s,DDWZ=%s,SHZ=%s,FID=%s,alarmText=\n",
        alarmInfo.getMsgSerial(),
        cleared,
        alarmInfo.getClearKeyword(),
        alarmInfo.getType(),
        alarmInfo.getLevel(),
        alarmInfo.getRaiseTime(),
        clearTime,
        alarmInfo.getNeType(),
        alarmInfo.getCause(),
        alarmInfo.getProbableCause(),
        alarmInfo.getNeId(),
        alarmInfo.getNeName(),
        alarmInfo.getSubNetName(),
        alarmInfo.getVendorId(),
        alarmInfo.getDdwz(),
        alarmInfo.getShz(),
        alarmInfo.getFid()
    );
  }

}
