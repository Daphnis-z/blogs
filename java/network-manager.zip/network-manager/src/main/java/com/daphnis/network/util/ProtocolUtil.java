package com.daphnis.network.util;

import com.daphnis.mybatis.entity.AlarmInfo;
import com.google.common.base.Strings;
import java.util.List;

public class ProtocolUtil {

  /**
   * 创建登录结果应答消息
   *
   * @param validateResult
   * @param faultReason
   * @return
   */
  public static String createLoginResp(boolean validateResult, String faultReason) {
    // ITE-CONNECTACK||VerifyResult=0,FaultReason=
    // 0:成功，1:失败
    return String.format("ITE-CONNECTACK||VerifyResult=%s,FaultReason=%s",
        validateResult ? 0 : 1, faultReason);
  }

  /**
   * 创建服务端发送给客户端的心跳消息
   *
   * @param alarmCount 心跳周期内发送的告警条数
   * @return
   */
  public static String createHeartMsg(int alarmCount) {
    return String.format("ITE-HEART||alarmNum=%s,alarmSn=%s", alarmCount,
        CommonUtil.getCurrentShortDateTime());
  }

  /**
   * 按协议生成告警消息
   *
   * @param alarmInfo
   * @return
   */
  public static String createAlarmMsg(AlarmInfo alarmInfo) {
    // ITE-View||msgSerial=20190618-1,cleared=0,clearKeyword=279786023,type=EQUIPMENT,
    // level=WARNING,raiseTime=2014-03-27 17:30:29,clearTime=,neType=PORT,
    // cause=R_LOS,probableCause=R_LOS,neId=0000000000000066474,neName=设备名,subNetName=三区局,
    // vendorId=华为,alarmText=

    // 对 cleared 进行转换，0：新增，1：清除
    String cleared = "0".equals(alarmInfo.getCleared()) ? "新增" : "清除";

    String clearTime =
        Strings.isNullOrEmpty(alarmInfo.getClearTime()) ? "" : alarmInfo.getClearTime();

    return String.format("ITE-View||msgSerial=%s,cleared=%s,clearKeyword=%s,type=%s,"
            + "level=%s,raiseTime=%s,clearTime=%s,neType=%s,cause=%s,probableCause=%s,"
            + "neId=%s,neName=%s,subNetName=%s,vendorId=%s,DDWZ=%s,SHZ=%s,FID=%s,alarmText=\n",
        alarmInfo.getMsgSerial(),
        cleared,
        alarmInfo.getClearKeyword(),
        alarmInfo.getType(),
        alarmInfo.getLevel(),
        alarmInfo.getRaiseTime(),
        clearTime,
        alarmInfo.getNeType(),
        alarmInfo.getCause(),
        alarmInfo.getProbableCause(),
        alarmInfo.getNeId(),
        alarmInfo.getNeName(),
        alarmInfo.getSubNetName(),
        alarmInfo.getVendorId(),
        alarmInfo.getDdwz(),
        alarmInfo.getShz(),
        alarmInfo.getFid()
    );
  }

  public static String createXmlAlarmMsgs(List<AlarmInfo> alarmInfos) {
//    <AlarmSummary>
//      <msgSerial>20181022-1</msgSerial>
//      <cleared>false</cleared>
//      <clearKeyword>35</clearKeyword>
//      <type>填写枚举值，需要后续补充</type>
//      <level> CRITICAL </level>
//      <raiseTime>20181022084655</raiseTime>
//      <clearTime></clearTime>
//      <neType>填写枚举值，需要后续补充</neType>
//      <cause>告警原因</cause>
//      <probableCause>告警详细原因</probableCause>
//      <neName>井号</neName>
//      <subNetName>管线局</subNetName>
//      <neId>IMEI</neId>
//      <vendorId>填写枚举值，需要后续补充</vendorId>
//      <alarmText>告警原始报文</alarmText>
//	  </AlarmSummary>

//    msgSerial=%s,cleared=%s,clearKeyword=%s,type=%s,"
//        + "level=%s,raiseTime=%s,clearTime=%s,neType=%s,cause=%s,probableCause=%s,"
//        + "neId=%s,neName=%s,subNetName=%s,vendorId=%s,DDWZ=%s,SHZ=%s,FID=%s,alarmText=
    StringBuilder alarmBuilder = new StringBuilder("");
    for (AlarmInfo alarmInfo : alarmInfos) {
      String cleared = "0".equals(alarmInfo.getCleared()) ? "新增" : "清除";
      String clearTime =
          Strings.isNullOrEmpty(alarmInfo.getClearTime()) ? "" : alarmInfo.getClearTime();

      StringBuilder strBuilder = new StringBuilder("<AlarmSummary>");

      strBuilder.append(String.format("<msgSerial>%s</msgSerial>", alarmInfo.getMsgSerial()));
      strBuilder.append(String.format("<cleared>%s</cleared>", cleared));
      strBuilder
          .append(String.format("<clearKeyword>%s</clearKeyword>", alarmInfo.getClearKeyword()));
      strBuilder.append(String.format("<type>%s</type>", alarmInfo.getType()));
      strBuilder.append(String.format("<level>%s</level>", alarmInfo.getLevel()));
      strBuilder.append(String.format("<raiseTime>%s</raiseTime>", alarmInfo.getRaiseTime()));
      strBuilder.append(String.format("<clearTime>%s</clearTime>", clearTime));

      strBuilder.append(String.format("<neType>%s</neType>", alarmInfo.getNeType()));
      strBuilder.append(String.format("<cause>%s</cause>", alarmInfo.getCause()));
      strBuilder
          .append(String.format("<probableCause>%s</probableCause>", alarmInfo.getProbableCause()));
      strBuilder.append(String.format("<neId>%s</neId>", alarmInfo.getNeId()));
      strBuilder.append(String.format("<neName>%s</neName>", alarmInfo.getNeName()));
      strBuilder.append(String.format("<subNetName>%s</subNetName>", alarmInfo.getSubNetName()));
      strBuilder.append(String.format("<vendorId>%s</vendorId>", alarmInfo.getVendorId()));
      strBuilder.append(String.format("<DDWZ>%s</DDWZ>", alarmInfo.getDdwz()));
      strBuilder.append(String.format("<SHZ>%s</SHZ>", alarmInfo.getShz()));
      strBuilder.append(String.format("<FID>%s</FID>", alarmInfo.getFid()));
      strBuilder.append(String.format("<alarmText>%s</alarmText>", ""));

      strBuilder.append("</AlarmSummary>");

      alarmBuilder.append(strBuilder.toString());
    }

    return alarmBuilder.toString();
  }

}
