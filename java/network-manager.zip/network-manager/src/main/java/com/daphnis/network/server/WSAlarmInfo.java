package com.daphnis.network.server;

import com.daphnis.mybatis.entity.AlarmInfo;
import com.daphnis.network.entity.WSAlarmParam;
import com.daphnis.network.util.CommonUtil;
import com.daphnis.network.util.ConfigUtil;
import com.daphnis.network.util.DBUtil;
import com.daphnis.network.util.ProtocolUtil;
import com.sun.net.httpserver.HttpExchange;
import com.sun.xml.internal.ws.developer.JAXWSProperties;
import java.util.List;
import javax.annotation.Resource;
import javax.jws.WebService;
import javax.xml.ws.Endpoint;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@WebService
public class WSAlarmInfo {

  private static Logger LOG = LoggerFactory.getLogger(WSAlarmInfo.class);

  private static final int SUCCESS = 0;
  private static final int TIMEOUT = 1;
  private static final int EXCEPTION = 2;

  @Resource
  private WebServiceContext context;

  public String getClientAddress() {
    try {
      MessageContext mc = context.getMessageContext();
      HttpExchange exchange = (HttpExchange) mc.get(JAXWSProperties.HTTP_EXCHANGE);
      return exchange.getRemoteAddress().getAddress().getHostAddress();
    } catch (Exception e) {
      LOG.error("get WebService client address error !!", e);
    }

    return "";
  }

  private WSAlarmParam parseXmlParams(String xmlParams) {
    try {
      Document document = DocumentHelper.parseText(xmlParams);
      Element rootEle = document.getRootElement();

      String startTime = rootEle.element("Starttime").getStringValue();
      String endTime = rootEle.element("Endtime").getStringValue();
      WSAlarmParam alarmParam = new WSAlarmParam(startTime, endTime);

      if (null != rootEle.element("NeName")) {
        alarmParam.setNeName(rootEle.element("NeName").getStringValue());
      }
      if (null != rootEle.element("Common1")) {
        alarmParam.setCommon1(rootEle.element("Common1").getStringValue());
      }

      return alarmParam;
    } catch (Exception e) {
      LOG.error("parse GetAlarmInfo api params error !!", e);
    }

    return new WSAlarmParam();
  }

  /**
   * 告警信息同步接口
   *
   * @param message
   * @return
   */
  public String GetAlarmInfo(String message) {
    String alarmRespTemplate = "<?xml version=\"1.0\" encoding=\"gb2312\"?><AlarmInfo>%s" +
        "<ResultInfo><result>%s</result>" +
        "<description>%s</description></ResultInfo></AlarmInfo>";
    String clientAddress = getClientAddress();
    if (!ServerTaskCache.clientAddress2ServerTask.containsKey(clientAddress)) {
      LOG.info(String.format("client %s is not login by socket..", clientAddress));
      return String.format(alarmRespTemplate, "", EXCEPTION, "客户端未连接 Socket 进行认证");
    }
    ServerTask serverTask = ServerTaskCache.clientAddress2ServerTask.get(clientAddress);
    if (serverTask.getSocket().isClosed()) {
      LOG.info(String.format("client %s is not login by socket..", clientAddress));
      return String.format(alarmRespTemplate, "", EXCEPTION, "客户端未连接 Socket 进行认证");
    }

    String alarmResp;
    try {
      WSAlarmParam alarmParam = parseXmlParams(message);

      String startTime = CommonUtil.shortDateMinute2StdDateTime(alarmParam.getStartTime());
      String endTime = CommonUtil.shortDateMinute2StdDateTime(alarmParam.getEndTime());
      List<AlarmInfo> alarmInfos = DBUtil
          .queryAlarmInfoByNeName(startTime, endTime, alarmParam.getNeName());

      if (alarmInfos.size() > ConfigUtil.getNetworkDataLimit()) {
        alarmResp = String
            .format(alarmRespTemplate, "", TIMEOUT, "查询的数据量过大，稍后从文件中获取结果");
        new WriteAlarmTask(alarmInfos, serverTask.getSocket()).start();
      } else {
        alarmResp = String
            .format(alarmRespTemplate, ProtocolUtil.createXmlAlarmMsgs(alarmInfos), SUCCESS, "");
      }
    } catch (Exception e) {
      LOG.error("execute GetAlarmInfo error !!", e);
      alarmResp = String.format(alarmRespTemplate, "", EXCEPTION, "服务端内部错误");
    }

    LOG.info("handle WebService client request complete,response: " + alarmResp);
    return alarmResp;
  }


  public static void start() {
    try {
      String address = String
          .format("http://%s:%s/Service/GetAlarmInfo", ConfigUtil.getServerHost(),
              ConfigUtil.getWebServicePort());

      // 通过EndPoint(端点服务)发布一个WebService
      Endpoint.publish(address, new WSAlarmInfo());
      LOG.info(String.format("start web service %s success..", address));
    } catch (Exception e) {
      LOG.error("start WebService server error !!", e);
    }
  }
}
