package com.daphnis.network.server;

import com.daphnis.network.entity.WSAlarmParam;
import com.daphnis.network.util.ConfigUtil;
import javax.jws.WebService;
import javax.xml.ws.Endpoint;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@WebService
public class WSAlarmInfo {

  private static Logger LOG = LoggerFactory.getLogger(WSAlarmInfo.class);

  private WSAlarmParam parseXmlParams(String xmlParams) {
    try {
      Document document = DocumentHelper.parseText(xmlParams);
      Element rootEle = document.getRootElement();

      String startTime = rootEle.element("Starttime").getStringValue();
      String endTime = rootEle.element("Endtime").getStringValue();
      WSAlarmParam alarmParam = new WSAlarmParam(startTime, endTime);

      if (null != rootEle.element("NeName")) {
        alarmParam.setNeName(rootEle.element("NeName").getStringValue());
      }
      if (null != rootEle.element("Common1")) {
        alarmParam.setCommon1(rootEle.element("Common1").getStringValue());
      }

      return alarmParam;
    } catch (Exception e) {
      LOG.error("parse GetAlarmInfo api params error !!", e);
    }

    return new WSAlarmParam();
  }

  /**
   * 告警信息同步接口
   *
   * @param message
   * @return
   */
  public String GetAlarmInfo(String message) {
    WSAlarmParam alarmParam = parseXmlParams(message);
    return "server say: " + message;
  }


  public static void start() {
    String address = String.format("http://%s:%s/Service/GetAlarmInfo", ConfigUtil.getServerHost(),
        ConfigUtil.getWebServicePort());

    // 通过EndPoint(端点服务)发布一个WebService
    Endpoint.publish(address, new WSAlarmInfo());
    LOG.info(String.format("start web service %s success..", address));
  }
}
