package com.daphnis.mybatis.util;

public class CommonUtil {

  public static void showMsg(Object msg) {
    System.out.println(msg.toString());
  }
}
