package com.daphnis.mybatis.entity;

public class AlarmInfo {

  private String msgSerial;
  private String cleared;
  private String clearKeyword;
  private String type;
  private String level;
  private String raiseTime;
  private String clearTime;
  private String neType;
  private String cause;
  private String probableCause;
  private String neId;
  private String neName;
  private String subNetName;
  private String vendorId;
  private String ddwz;
  private String shz;
  private String fid;


  public String getMsgSerial() {
    return msgSerial;
  }

  public void setMsgSerial(String msgSerial) {
    this.msgSerial = msgSerial;
  }

  public String getCleared() {
    return cleared;
  }

  public void setCleared(String cleared) {
    this.cleared = cleared;
  }

  public String getClearKeyword() {
    return clearKeyword;
  }

  public void setClearKeyword(String clearKeyword) {
    this.clearKeyword = clearKeyword;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getLevel() {
    return level;
  }

  public void setLevel(String level) {
    this.level = level;
  }

  public String getRaiseTime() {
    return raiseTime;
  }

  public void setRaiseTime(String raiseTime) {
    this.raiseTime = raiseTime;
  }

  public String getClearTime() {
    return clearTime;
  }

  public void setClearTime(String clearTime) {
    this.clearTime = clearTime;
  }

  public String getNeType() {
    return neType;
  }

  public void setNeType(String neType) {
    this.neType = neType;
  }

  public String getCause() {
    return cause;
  }

  public void setCause(String cause) {
    this.cause = cause.replace("\n", "").replace(",", "");
  }

  public String getProbableCause() {
    return probableCause;
  }

  public void setProbableCause(String probableCause) {
    this.probableCause = probableCause.replace("\n", "").replace(",", "");
  }

  public String getNeId() {
    return neId;
  }

  public void setNeId(String neId) {
    this.neId = neId;
  }

  public String getNeName() {
    return neName;
  }

  public void setNeName(String neName) {
    this.neName = neName.replace("\n", "").replace(",", "");
  }

  public String getSubNetName() {
    return subNetName;
  }

  public void setSubNetName(String subNetName) {
    this.subNetName = subNetName.replace("\n", "").replace(",", "");
  }

  public String getVendorId() {
    return vendorId;
  }

  public void setVendorId(String vendorId) {
    this.vendorId = vendorId.replace("\n", "").replace(",", "");
  }

  public String getDdwz() {
    return ddwz;
  }

  public void setDdwz(String ddwz) {
    this.ddwz = ddwz;
  }

  public String getShz() {
    return shz;
  }

  public void setShz(String shz) {
    this.shz = shz;
  }

  public String getFid() {
    return fid;
  }

  public void setFid(String fid) {
    this.fid = fid;
  }
}
