package com.daphnis.network;

import com.daphnis.network.wsclient.WSAlarmClient;

public class NetworkWSClientMain {

  public static void main(String[] args) {
    WSAlarmClient alarmClient = new WSAlarmClient();
    alarmClient.start();
  }

}
