package com.daphnis.network.server;

import com.daphnis.network.entity.Heartbeat;
import com.daphnis.network.util.ConfigUtil;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ServerTask implements Runnable {

  private static Logger LOG = LoggerFactory.getLogger(ServerTask.class);

  Heartbeat heartbeat = new Heartbeat();
  boolean stopTask = false;

  Socket socket;
  DataInputStream inStream;
  DataOutputStream outStream;

  String clientAddress;

  public ServerTask(Socket socket, DataInputStream inStream, DataOutputStream outStream) {
    this.socket = socket;
    this.inStream = inStream;
    this.outStream = outStream;
    this.clientAddress = socket.getInetAddress().getHostAddress();
  }

  @Override
  public void run() {
    LOG.info("start a server task,client address: " + socket.getInetAddress().getHostAddress());

    ServerReadTask readTask = new ServerReadTask();
    ServerWriteTask writeTask = new ServerWriteTask();
    readTask.start();
    writeTask.start();

    long heartAckTime = ConfigUtil.getHeartAckTime() * 1000;

    while (true) {
      try {
        Thread.sleep(1000);

        // 做心跳检测
        synchronized (heartbeat) {
          LOG.error("主 " + heartbeat.isSendHeart() + " " + heartbeat.isSendHeart());
          if (heartbeat.isSendHeart()) {
            if (heartbeat.isReceiveHeart()) {
              heartbeat.setSendHeart(false);
              heartbeat.setReceiveHeart(false);
              heartbeat.setFailTimes(0);
            }

            LOG.error(
                String.format("主 %s %s", System.currentTimeMillis(), heartbeat.getHeartTime()));
            if (System.currentTimeMillis() - heartbeat.getHeartTime() > heartAckTime) {
              heartbeat.setFailTimes(heartbeat.getFailTimes() + 1);
              if (heartbeat.getFailTimes() >= ConfigUtil.getHeartLimitTimes()) {
                stopTask = true;
                break;
              }
            }
          }
        }

        if (stopTask) {
          break;
        }

      } catch (Exception e) {
        LOG.error("server task error !!", e);
      }
    }

    try {
      socket.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
    LOG.info(String.format("client: %s is offline,server task will stop..", clientAddress));
  }

  public class ServerReadTask extends Thread {

    @Override
    public void run() {
      LOG.info("start server read task,client address: " + clientAddress);

      while (!stopTask) {
        try {
          String msg = inStream.readUTF();
          LOG.info("receive client message: " + msg);

          if (msg.startsWith("ITE-HEARTACK")) {
            synchronized (heartbeat) {
              heartbeat.setReceiveHeart(true);
            }
          }
        } catch (Exception e) {
          LOG.error("server read task error !!", e);
          synchronized (heartbeat) {
            stopTask = true;
          }
        }
      }

    }

  }

  public class ServerWriteTask extends Thread {

    @Override
    public void run() {
      long heartbeatIntervalMillis = ConfigUtil.getHeartbeatInterval() * 1000;
      LOG.info("start server write task,client address: " + clientAddress);

      while (!stopTask) {
        try {
          outStream.writeUTF("ITE-HEART||alarmNum=21,alarmSn=20190618130049");

          synchronized (heartbeat) {
            heartbeat.setSendHeart(true);
            heartbeat.setHeartTime(System.currentTimeMillis());
          }

          Thread.sleep(heartbeatIntervalMillis);
        } catch (Exception e) {
          LOG.error("server write task error !!", e);
          synchronized (heartbeat) {
            stopTask = true;
          }
        }
      }

    }

  }


}
