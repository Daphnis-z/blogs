package com.daphnis.mybatis.entity;

public class ClientInfo {

  private String clientAddress;
  private String lastLoginTime;

  public ClientInfo(String clientAddress, String lastLoginTime) {
    this.clientAddress = clientAddress;
    this.lastLoginTime = lastLoginTime;
  }

  public String getClientAddress() {
    return clientAddress;
  }

  public void setClientAddress(String clientAddress) {
    this.clientAddress = clientAddress;
  }

  public String getLastLoginTime() {
    return lastLoginTime;
  }

  public void setLastLoginTime(String lastLoginTime) {
    this.lastLoginTime = lastLoginTime;
  }
}
