package com.daphnis.mybatis.entity;

public class ClientInfo {

  private String clientAddress;
  private String userId;
  private String loginTime;
  private String logoutTime = "";

  public ClientInfo(String clientAddress, String userId) {
    this.clientAddress = clientAddress;
    this.userId = userId;
  }

  public ClientInfo(String clientAddress, String userId, String loginTime,
      String logoutTime) {
    this.clientAddress = clientAddress;
    this.userId = userId;
    this.loginTime = loginTime;
    this.logoutTime = logoutTime;
  }

  public String getClientAddress() {
    return clientAddress;
  }

  public void setClientAddress(String clientAddress) {
    this.clientAddress = clientAddress;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getLoginTime() {
    return loginTime;
  }

  public void setLoginTime(String loginTime) {
    this.loginTime = loginTime;
  }

  public String getLogoutTime() {
    return logoutTime;
  }

  public void setLogoutTime(String logoutTime) {
    this.logoutTime = logoutTime;
  }
}
