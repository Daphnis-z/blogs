package com.daphnis.network.protocol;

public class ResendProtocol extends BaseProtocol {

  public static final String MSG_TYPE = "ITE-RESEND";

}
