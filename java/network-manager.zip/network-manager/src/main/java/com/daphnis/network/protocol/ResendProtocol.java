package com.daphnis.network.protocol;

import com.daphnis.mybatis.entity.AlarmInfo;
import com.daphnis.network.util.CommonUtil;
import com.daphnis.network.util.ConfigUtil;
import com.daphnis.network.util.DBUtil;
import com.daphnis.network.util.ProtocolUtil;
import com.google.common.collect.Lists;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ResendProtocol extends BaseProtocol {

  private static Logger LOG = LoggerFactory.getLogger(ResendProtocol.class);

  public static final String MSG_TYPE = "ITE-RESEND";

  private String startMsgSerial;

  @Override
  public void analysisMessage(String message) {
    // ITE-RESEND||msgSerial=20190618-3
    super.analysisMessage(message);

    String[] data = super.msgContent.split("=");
    if (data.length == 2) {
      startMsgSerial = data[1];
    }
  }

  /**
   * 返回指定 告警消息序号开始的 n分钟内的告警数据
   *
   * @return
   */
  public List<String> geneAlarmMsgs() {
    try {
      long endMills = System.currentTimeMillis();
      long startMills = endMills - CommonUtil.mintue2Mills(ConfigUtil.getAlarmLimitTime());

      String startTime = CommonUtil.formatTimeMills(startMills);
      String endTime = CommonUtil.formatTimeMills(endMills);
      List<AlarmInfo> alarmInfos = DBUtil
          .queryAlarmInfoByTimeSerial(startTime, endTime, startMsgSerial);

      // 将告警转换成和客户端约定的格式
      List<String> alarmMsgs = Lists.newArrayList();
      for (AlarmInfo alarmInfo : alarmInfos) {
        alarmMsgs.add(ProtocolUtil.createAlarmMsg(alarmInfo));
      }

      return alarmMsgs;
    } catch (Exception e) {
      LOG.error("generate resend alarm info error !!", e);
    }

    return Lists.newArrayList();
  }
}
