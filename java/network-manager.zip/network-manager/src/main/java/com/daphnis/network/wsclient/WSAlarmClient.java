package com.daphnis.network.wsclient;

import com.daphnis.network.util.CommonUtil;
import com.daphnis.network.util.ConfigUtil;
import com.daphnis.network.util.SocketUtil;
import com.google.common.base.Charsets;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Scanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WSAlarmClient {

  private static Logger LOG = LoggerFactory.getLogger(WSAlarmClient.class);

  public static String params2Xml(String startTime, String endTime, String neName) {
    String xmlPara = "<?xml version=\"1.0\" encoding=\"gb2312\"?>" +
        "<MessageInfo>" +
        "<Starttime>%s</Starttime>" +
        "<Endtime>%s</Endtime>" +
        "<NeName>%s</NeName>" +
        "</MessageInfo>";

    return String.format(xmlPara, startTime, endTime, neName);
  }

  public void start() {
    String serverName = ConfigUtil.getServerHost();
    try {
      LOG.info(String
          .format("connect to server: %s on port: %s", serverName, ConfigUtil.getServerPort()));
      Socket socket = new Socket(serverName, ConfigUtil.getServerPort());
      LOG.info(String.format("connect %s success..", socket.getRemoteSocketAddress()));

      BufferedReader bufferReader = new BufferedReader(
          new InputStreamReader(socket.getInputStream(), Charsets.UTF_8));
      BufferedWriter bufferWriter = new BufferedWriter(
          new OutputStreamWriter(socket.getOutputStream(), Charsets.UTF_8));

      // 在服务端进行验证
      Scanner scanner = new Scanner(System.in);
      System.out.println("请输入用户名（Enter 结束输入）：");
      String userName = scanner.nextLine();
      System.out.println("请输入密码（Enter 结束输入）：");
      String password = scanner.nextLine();
      SocketUtil.writeMessage2Stream(
          String.format("ITE-CONNECT||UserName=%s,Password=%s", userName, password), bufferWriter);

      // 解析服务端返回的认证结果
      String msg = bufferReader.readLine();
      if (msg.startsWith("ITE-CONNECTACK||VerifyResult=0")) {
        System.out.println("receive from server: " + msg);
        System.out.println("已通过服务端认证..");
      } else {
        System.out.println("服务端认证失败：" + msg);
        return;
      }

      WSAlarmInfoServiceLocator locator = new WSAlarmInfoServiceLocator();
      LOG.info("server address: " + locator.getWSAlarmInfoPortAddress());

      WSAlarmInfo wsAlarmInfo = locator.getWSAlarmInfoPort();

      System.out.println("请输入开始时间（eg. 202012232111）：");
      String startTime = scanner.nextLine();

      System.out.println("请输入结束时间（eg. 202012222309）：");
      String endTime = scanner.nextLine();

      System.out.println("请输入设备名称（Enter 跳过）：");
      String neName = scanner.nextLine();

      String serverResp = wsAlarmInfo.getAlarmInfo(params2Xml(startTime, endTime, neName));
      LOG.info("receive from server: " + serverResp);

      // 开始正式接受服务端的消息
      while (true) {
        msg = bufferReader.readLine();
        System.out.println("receive from server: " + msg);

        if (msg.startsWith("ITE-HEART")) {
          SocketUtil
              .writeMessage2Stream("ITE-HEARTACK||alarmSn=" + CommonUtil.getCurrentShortDateTime(),
                  bufferWriter);
        }

        Thread.sleep(1000);
      }

//      socket.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}
