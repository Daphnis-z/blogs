package com.daphnis.network.wsclient;

import com.daphnis.network.util.CommonUtil;
import com.daphnis.network.util.ConfigUtil;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.util.Scanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WSAlarmClient {

  private static Logger LOG = LoggerFactory.getLogger(WSAlarmClient.class);

  public static String params2Xml(String startTime, String endTime, String neName) {
//    Starttime
//    Endtime
//    NeName
//    Common1
//  <?xml version="1.0" encoding="gb2312"?>
//  <MessageInfo>
//  <Starttime > 201810221609</Starttime >
//  <Endtime > 201810231609 </Endtime >
//  </MessageInfo >

    String xmlPara = "<?xml version=\"1.0\" encoding=\"gb2312\"?>" +
        "<MessageInfo>" +
        "<Starttime>%s</Starttime>" +
        "<Endtime>%s</Endtime>" +
        "<NeName>%s</NeName>" +
        "</MessageInfo>";

    return String.format(xmlPara, startTime, endTime, "设备名");
  }

  public void start() {
    String serverName = ConfigUtil.getServerHost();
    int serverPort = Integer.parseInt(ConfigUtil.getServerPort());
    try {
      LOG.info(String.format("connect to server: %s on port: %s", serverName, serverPort));
      Socket socket = new Socket(serverName, serverPort);
      LOG.info(String.format("connect %s success..", socket.getRemoteSocketAddress()));

      DataOutputStream outStream = new DataOutputStream(socket.getOutputStream());
      DataInputStream inStream = new DataInputStream(socket.getInputStream());

      outStream
          .writeUTF(String.format("ITE-CONNECT||UserName=%s,Password=%s", "admin", "inms123456"));

      // 解析服务端返回的认证结果
      String msg = inStream.readUTF();
      if (msg.startsWith("ITE-CONNECTACK||VerifyResult=0")) {
        System.out.println("receive from server: " + msg);
        System.out.println("已通过服务端认证..");
      } else {
        System.out.println("服务端认证失败：" + msg);
        return;
      }

      WSAlarmInfoServiceLocator locator = new WSAlarmInfoServiceLocator();
      LOG.info("server address: " + locator.getWSAlarmInfoPortAddress());

      WSAlarmInfo wsAlarmInfo = locator.getWSAlarmInfoPort();

      Scanner scanner = new Scanner(System.in);
      System.out.println("请输入开始时间（eg. 202012232111）：");
      String startTime = scanner.nextLine();

      System.out.println("请输入结束时间（eg. 202012222309）：");
      String endTime = scanner.nextLine();

      String serverResp = wsAlarmInfo.getAlarmInfo(params2Xml(startTime, endTime, ""));
      LOG.info("receive from server: " + serverResp);

      // 开始正式接受服务端的消息
      while (true) {
        msg = inStream.readUTF();
        System.out.println("receive from server: " + msg);

        if (msg.startsWith("ITE-HEART")) {
          outStream.writeUTF("ITE-HEARTACK||alarmSn=" + CommonUtil.getCurrentShortDateTime());
        }

        Thread.sleep(1000);
      }

//      socket.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}
