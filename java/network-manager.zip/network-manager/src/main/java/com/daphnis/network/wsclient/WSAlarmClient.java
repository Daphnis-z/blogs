package com.daphnis.network.wsclient;

public class WSAlarmClient {


  public static String params2Xml(String startTime, String endTime, String neName) {
//    Starttime
//    Endtime
//    NeName
//    Common1
//  <?xml version="1.0" encoding="gb2312"?>
//  <MessageInfo>
//  <Starttime > 201810221609</Starttime >
//  <Endtime > 201810231609 </Endtime >
//  </MessageInfo >

    String xmlPara = "<?xml version=\"1.0\" encoding=\"gb2312\"?>" +
        "<MessageInfo>" +
        "<Starttime>%s</Starttime>" +
        "<Endtime>%s</Endtime>" +
        "<NeName>%s</NeName>" +
        "</MessageInfo>";

    return String.format(xmlPara, startTime, endTime, "设备名");
  }

  public static void main(String[] argv) {

    try {
      WSAlarmInfoServiceLocator locator = new WSAlarmInfoServiceLocator();
      WSAlarmInfo wsAlarmInfo = locator.getWSAlarmInfoPort();

      System.out.println(wsAlarmInfo.getAlarmInfo(params2Xml("202012221609", "202012222309", "")));

    } catch (javax.xml.rpc.ServiceException ex) {
      ex.printStackTrace();
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

}
