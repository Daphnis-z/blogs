package com.daphnis.mybatis.mapper;

import com.daphnis.mybatis.entity.ClientInfo;
import org.apache.ibatis.annotations.Param;

public interface ClientInfoMapper {

  int insertOneClientInfo(ClientInfo clientInfo);

  ClientInfo selectOneClientInfo(@Param("clientAddress") String clientAddress);

  int updateClientInfo(ClientInfo clientInfo);

}
