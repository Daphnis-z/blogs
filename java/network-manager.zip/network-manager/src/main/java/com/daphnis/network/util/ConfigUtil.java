package com.daphnis.network.util;

import java.io.IOException;
import java.util.Properties;

public class ConfigUtil {

  private static Properties prop = new Properties();

  static {
    try {
      prop.load(ConfigUtil.class.getClassLoader().getResourceAsStream("network.properties"));
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public static String getServerHost() {
    return prop.getProperty("server.host");
  }

  public static String getServerPort() {
    return prop.getProperty("server.port");
  }

  public static int getHeartbeatInterval() {
    return Integer.parseInt(prop.getProperty("heartbeat.interval.seconds", "60"));
  }

  public static int getHeartLimitTimes() {
    return Integer.parseInt(prop.getProperty("heartbeat.limit.times", "3"));
  }

  public static int getHeartAckTime() {
    return Integer.parseInt(prop.getProperty("heartbeat.ack.seconds", "10"));
  }

  public static int getAlarmLimitTime() {
    return Integer.parseInt(prop.getProperty("alarm.limit.minutes", "10"));
  }


}
