package com.daphnis.network.server;

import com.daphnis.mybatis.entity.AlarmInfo;
import com.daphnis.network.util.ConfigUtil;
import com.daphnis.network.util.ProtocolUtil;
import com.daphnis.network.util.SocketUtil;
import com.google.common.base.Charsets;
import com.google.common.io.Files;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.Socket;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WriteAlarmTask extends Thread {

  private static Logger LOG = LoggerFactory.getLogger(WriteAlarmTask.class);

  private List<AlarmInfo> alarmInfos;
  private Socket socket;
  private String clientAddress;


  public WriteAlarmTask(List<AlarmInfo> alarmInfos, Socket socket) {
    this.alarmInfos = alarmInfos;
    this.socket = socket;
    clientAddress = socket.getInetAddress().getHostAddress();
  }

  @Override
  public void run() {
    try {
      LOG.info("write alarm task start,alarm count: " + alarmInfos.size());
      String xmlAlarms = ProtocolUtil.createXmlAlarmMsgs(alarmInfos);
      String fileName = String
          .format("%s/alarm-%s.xml", ConfigUtil.getDataOutputDir(), System.currentTimeMillis());

      Files.write(xmlAlarms, new File(fileName), Charsets.UTF_8);
      LOG.info("xml alarm data have save to " + fileName);

      if (socket.isClosed()) {
        LOG.warn(clientAddress + " socket is closed,can not send WebService response !");
      } else {
        String msg = "ITE-ALARM||filePath=" + fileName;
        SocketUtil.writeMessage2Stream(msg, new DataOutputStream(socket.getOutputStream()));
        LOG.info(String.format("send message: %s to client: %s success..", msg, clientAddress));
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}
