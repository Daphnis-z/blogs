package com.daphnis.network.entity;

public class WSAlarmParam {

  private String startTime;
  private String endTime;
  private String neName;
  private String common1;

  public WSAlarmParam() {
  }

  public WSAlarmParam(String startTime, String endTime) {
    this.startTime = startTime;
    this.endTime = endTime;
  }

  public WSAlarmParam(String startTime, String endTime, String neName) {
    this.startTime = startTime;
    this.endTime = endTime;
    this.neName = neName;
  }

  public String getStartTime() {
    return startTime;
  }

  public void setStartTime(String startTime) {
    this.startTime = startTime;
  }

  public String getEndTime() {
    return endTime;
  }

  public void setEndTime(String endTime) {
    this.endTime = endTime;
  }

  public String getNeName() {
    return neName;
  }

  public void setNeName(String neName) {
    this.neName = neName;
  }

  public String getCommon1() {
    return common1;
  }

  public void setCommon1(String common1) {
    this.common1 = common1;
  }
}
