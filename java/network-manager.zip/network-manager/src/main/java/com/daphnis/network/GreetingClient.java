package com.daphnis.network;

import com.google.common.base.Charsets;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class GreetingClient {

  public static void main(String[] args) {
    String serverName = "127.0.0.1";
    int port = 8686;
    try {
      System.out.println("Connecting to " + serverName + " on port " + port);
      Socket client = new Socket(serverName, port);

      System.out.println("Just connected to " + client.getRemoteSocketAddress());
      OutputStream outToServer = client.getOutputStream();
      BufferedWriter writer = new BufferedWriter(
          new OutputStreamWriter(outToServer, Charsets.UTF_8));

      writer.write("服务端你好!\n");
      writer.flush();
      writer.close();
//      InputStream inFromServer = client.getInputStream();
//      DataInputStream in = new DataInputStream(inFromServer);
//
//      System.out.println("Server says: " + in.readUTF());
      client.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }


}

