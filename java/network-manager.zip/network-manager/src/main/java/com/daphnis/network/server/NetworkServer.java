package com.daphnis.network.server;

import com.daphnis.network.util.ConfigUtil;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NetworkServer {

  private static Logger LOG = LoggerFactory.getLogger(NetworkServer.class);

  public NetworkServer() {
  }

  /**
   * 启动网络管理服务器
   */
  public void start() {
    LOG.info("network manager server is start ..");

    ExecutorService executorService = Executors.newCachedThreadPool();

    executorService.submit(new AlarmSerialTask());

    int connectionCount = 0;
    try (ServerSocket serverSocket = new ServerSocket(ConfigUtil.getServerPort())) {
      while (true) {
        LOG.info("network manager server listen on port: " + serverSocket.getLocalPort());

        Socket socket = serverSocket.accept();
        ++connectionCount;

        String clientAddress = socket.getInetAddress().getHostAddress();
        LOG.info("receive a connect request,ip: " + clientAddress);

        ServerTask serverTask = new ServerTask(socket);
        executorService.submit(serverTask);

        ServerTaskCache.clientAddress2ServerTask.put(clientAddress, serverTask);
        LOG.info("receive client connection count: " + connectionCount);
      }
    } catch (Exception e) {
      LOG.error("network manager server error !!", e);
    }
  }

}




