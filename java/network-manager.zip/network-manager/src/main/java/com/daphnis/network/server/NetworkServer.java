package com.daphnis.network.server;

import com.daphnis.mybatis.entity.Account;
import com.daphnis.mybatis.mapper.AccountMapper;
import com.google.common.base.Strings;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.Reader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NetworkServer {

  private static Logger LOG = LoggerFactory.getLogger(NetworkServer.class);

  private static final String ENV = "development";


  private SqlSessionFactory sqlSessionFactory;

  public NetworkServer() {
    init();
  }

  private void init() {
    try {
      Reader reader = Resources.getResourceAsReader("mybatis-config.xml");
      sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader, ENV);
    } catch (Exception e) {
      LOG.error("init server error !!", e);
    }
  }

  /**
   * 启动网络管理服务器
   */
  public void start() {
    LOG.info("network manager server is start ..");

    int serverPort = 8686;
    ExecutorService executorService = Executors.newCachedThreadPool();

    try (ServerSocket serverSocket = new ServerSocket(serverPort)) {
      while (true) {
        LOG.info("network server listen on port: " + serverSocket.getLocalPort());

        Socket socket = serverSocket.accept();
        String userIP = socket.getInetAddress().getHostAddress();
        LOG.info("receive a connect request,ip: " + userIP);

        if (validateClient(socket)) {
          LOG.info("validate client success ..");
        } else {
          LOG.info("validate client fail !!");
        }
      }
    } catch (IOException e) {
      LOG.error("server error: ", e);
    }
  }

  private boolean validateClient(Socket socket) {
    try (DataInputStream inStream = new DataInputStream(socket.getInputStream())) {
      String msg = inStream.readUTF();
      // ITE-CONNECT||UserName=admin,Password=inms123456
      String[] data = msg.split("\\|\\|");
      if (data.length != 2 || !"ITE-CONNECT".equals(data[0])) {
        return false;
      }

      Account account = parseAccount(data[1]);
      if (Strings.isNullOrEmpty(account.getUserName())) {
        return false;
      }

      SqlSession sqlSession = sqlSessionFactory.openSession();
      AccountMapper accountMapper = sqlSession.getMapper(AccountMapper.class);
      Account tgtAccount = accountMapper.selectOneAccount(account.getUserName());
      sqlSession.close();

      if (tgtAccount == null) {
        return false;
      }
      return account.getPassword().equals(tgtAccount.getPassword());
    } catch (Exception e) {
      LOG.error("validate client error !!", e);
    }

    return false;
  }

  protected Account parseAccount(String strAccount) {
    try {
      // UserName=admin,Password=inms123456
      String[] data = strAccount.split(",");
      if (data.length == 2) {
        String userName = data[0].split("=")[1];
        String password = data[1].split("=")[1];
        return new Account(userName, password);
      }
    } catch (Exception e) {
      LOG.debug(String.format("parse account by %s error !!", strAccount), e);
    }

    return new Account();
  }
}




