package com.daphnis.network.server;

import com.daphnis.network.util.ConfigUtil;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NetworkServer {

  private static Logger LOG = LoggerFactory.getLogger(NetworkServer.class);

  public NetworkServer() {
  }

  /**
   * 启动网络管理服务器
   */
  public void start() {
    LOG.info("network manager server is start ..");

    int serverPort = Integer.parseInt(ConfigUtil.getServerPort());
    ExecutorService executorService = Executors.newCachedThreadPool();

    int connectionCount = 0;
    try (ServerSocket serverSocket = new ServerSocket(serverPort)) {
      while (true) {
        LOG.info("network manager server listen on port: " + serverSocket.getLocalPort());

        Socket socket = serverSocket.accept();
        ++connectionCount;
        LOG.info("receive a connect request,ip: " + socket.getInetAddress().getHostAddress());

        executorService.submit(new ServerTask(socket));
        LOG.info("receive client connection count: " + connectionCount);
      }
    } catch (Exception e) {
      LOG.error("network manager server error !!", e);
    }
  }

}




