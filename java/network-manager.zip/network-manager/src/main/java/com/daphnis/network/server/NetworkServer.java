package com.daphnis.network.server;

import com.daphnis.mybatis.entity.Account;
import com.daphnis.mybatis.mapper.AccountMapper;
import com.daphnis.network.util.ConfigUtil;
import com.daphnis.network.util.DBUtil;
import com.daphnis.network.util.ProtocolUtil;
import com.google.common.base.Strings;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NetworkServer {

  private static Logger LOG = LoggerFactory.getLogger(NetworkServer.class);

  public NetworkServer() {
    init();
  }

  private void init() {
  }

  /**
   * 启动网络管理服务器
   */
  public void start() {
    LOG.info("network manager server is start ..");

    int serverPort = Integer.parseInt(ConfigUtil.getServerPort());
    ExecutorService executorService = Executors.newCachedThreadPool();

    try (ServerSocket serverSocket = new ServerSocket(serverPort)) {
      while (true) {
        LOG.info("network server listen on port: " + serverSocket.getLocalPort());

        Socket socket = serverSocket.accept();
        String userIP = socket.getInetAddress().getHostAddress();
        LOG.info("receive a connect request,ip: " + userIP);

        DataInputStream inStream = new DataInputStream(socket.getInputStream());
        DataOutputStream outStream = new DataOutputStream(socket.getOutputStream());
        if (validateClient(inStream, outStream)) {
          LOG.info("validate client success ..");
          executorService.submit(new ServerTask(socket, inStream, outStream));
        } else {
          LOG.info("validate client fail,will close socket !!");
          socket.close();
        }
      }
    } catch (IOException e) {
      LOG.error("server error: ", e);
    }
  }

  private boolean validateClient(DataInputStream inStream, DataOutputStream outStream) {
    try {
      String msg = inStream.readUTF();
      // ITE-CONNECT||UserName=admin,Password=inms123456
      String[] data = msg.split("\\|\\|");
      if (data.length != 2 || !"ITE-CONNECT".equals(data[0])) {
        outStream.writeUTF(ProtocolUtil.createLoginResp(false, "验证消息格式错误"));
        return false;
      }

      Account account = parseAccount(data[1]);
      if (Strings.isNullOrEmpty(account.getUserName())) {
        outStream.writeUTF(ProtocolUtil.createLoginResp(false, "缺少用户名或密码"));
        return false;
      }

      SqlSession sqlSession = DBUtil.openSession();
      AccountMapper accountMapper = sqlSession.getMapper(AccountMapper.class);
      Account tgtAccount = accountMapper.selectOneAccount(account.getUserName());
      sqlSession.close();

      if (tgtAccount == null || !account.getPassword().equals(tgtAccount.getPassword())) {
        outStream.writeUTF(ProtocolUtil.createLoginResp(false, "用户名或密码错误"));
        return false;
      }

      outStream.writeUTF(ProtocolUtil.createLoginResp(true, ""));
      return true;
    } catch (Exception e) {
      LOG.error("validate client error !!", e);
    }

    try {
      outStream.writeUTF(ProtocolUtil.createLoginResp(false, "服务出现异常"));
    } catch (IOException e) {
      LOG.error("向客户端发送应答消息错误 ！！", e);
    }
    return false;
  }

  protected Account parseAccount(String strAccount) {
    try {
      // UserName=admin,Password=inms123456
      String[] data = strAccount.split(",");
      if (data.length == 2) {
        String userName = data[0].split("=")[1];
        String password = data[1].split("=")[1];
        return new Account(userName, password);
      }
    } catch (Exception e) {
      LOG.debug(String.format("parse account by %s error !!", strAccount), e);
    }

    return new Account();
  }

}




