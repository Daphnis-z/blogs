package com.daphnis.mybatis.entity;

public class AlarmStatus {

  private String msgSerial;
  private String cleared;
  private String clearKeyword;
  private int sendStatus = 0;

  public AlarmStatus(String msgSerial, String cleared, String clearKeyword) {
    this.msgSerial = msgSerial;
    this.cleared = cleared;
    this.clearKeyword = clearKeyword;
  }

  public String getMsgSerial() {
    return msgSerial;
  }

  public void setMsgSerial(String msgSerial) {
    this.msgSerial = msgSerial;
  }

  public String getCleared() {
    return cleared;
  }

  public void setCleared(String cleared) {
    this.cleared = cleared;
  }

  public String getClearKeyword() {
    return clearKeyword;
  }

  public void setClearKeyword(String clearKeyword) {
    this.clearKeyword = clearKeyword;
  }

  public int getSendStatus() {
    return sendStatus;
  }

  public void setSendStatus(int sendStatus) {
    this.sendStatus = sendStatus;
  }
}
