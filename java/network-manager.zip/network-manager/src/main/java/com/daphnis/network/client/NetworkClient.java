package com.daphnis.network.client;

import com.daphnis.network.util.ConfigUtil;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NetworkClient {

  private static Logger LOG = LoggerFactory.getLogger(NetworkClient.class);

  public void start() {
    LOG.info("network manager client start ..");

    String serverName = ConfigUtil.getServerHost();
    int serverPort = Integer.parseInt(ConfigUtil.getServerPort());
    try {
      LOG.info(String.format("connect to server: %s on port: %s", serverName, serverPort));
      Socket socket = new Socket(serverName, serverPort);
      LOG.info(String.format("connect %s success..", socket.getRemoteSocketAddress()));

      OutputStream outToServer = socket.getOutputStream();
      DataOutputStream out = new DataOutputStream(outToServer);
      out.writeUTF("ITE-CONNECT||UserName=admin,Password=inms123456");

      InputStream inFromServer = socket.getInputStream();
      DataInputStream inStream = new DataInputStream(inFromServer);

      while (true) {
        String msg = inStream.readUTF();
        System.out.println("Server says: " + msg);

        if (msg.startsWith("ITE-HEART")) {
          out.writeUTF("ITE-HEARTACK|| alarmSn=20190618130049");
        }

        Thread.sleep(1000);
      }

//      socket.close();
    } catch (Exception e) {
      e.printStackTrace();
    }

  }


}




