package com.daphnis.network.client;

import com.daphnis.network.util.CommonUtil;
import com.daphnis.network.util.ConfigUtil;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.util.Scanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NetworkClient {

  private static Logger LOG = LoggerFactory.getLogger(NetworkClient.class);

  public void start() {
    LOG.info("network manager client start ..");

    String serverName = ConfigUtil.getServerHost();
    int serverPort = Integer.parseInt(ConfigUtil.getServerPort());
    try {
      LOG.info(String.format("connect to server: %s on port: %s", serverName, serverPort));
      Socket socket = new Socket(serverName, serverPort);
      LOG.info(String.format("connect %s success..", socket.getRemoteSocketAddress()));

      DataOutputStream outStream = new DataOutputStream(socket.getOutputStream());
      DataInputStream inStream = new DataInputStream(socket.getInputStream());

      boolean heartEnable = true;

//      String msg;
//      outStream
//          .writeUTF(String.format("ITE-CONNECT||UserName=%s,Password=%s", "admin", "inms123456"));

      // 在服务端进行验证
      Scanner scanner = new Scanner(System.in);
      System.out.println("请输入用户名（Enter 结束输入）：");
      String userName = scanner.nextLine();
      System.out.println("请输入密码（Enter 结束输入）：");
      String password = scanner.nextLine();
      outStream
          .writeUTF(String.format("ITE-CONNECT||UserName=%s,Password=%s", userName, password));

      // 解析服务端返回的认证结果
      String msg = inStream.readUTF();
      if (msg.startsWith("ITE-CONNECTACK||VerifyResult=0")) {
        System.out.println("receive from server: " + msg);
        System.out.println("已通过服务端认证..");

        System.out.println("请输入是否回复服务端的心跳验证（0:不回复，1:回复）：");
        heartEnable = "1".equals(scanner.nextLine());
      } else {
        System.out.println("服务端认证失败：" + msg);
        return;
      }

      // 开始正式接受服务端的消息
      while (true) {
        msg = inStream.readUTF();
        System.out.println("receive from server: " + msg);

        if (msg.startsWith("ITE-HEART") && heartEnable) {
          outStream.writeUTF("ITE-HEARTACK||alarmSn=" + CommonUtil.getCurrentShortDateTime());
        }

        Thread.sleep(1000);
      }

//      socket.close();
    } catch (Exception e) {
      e.printStackTrace();
    }

  }


}




