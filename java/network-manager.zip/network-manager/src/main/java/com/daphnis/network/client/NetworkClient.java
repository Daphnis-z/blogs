package com.daphnis.network.client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NetworkClient {

  private static Logger LOG = LoggerFactory.getLogger(NetworkClient.class);

  public void start() {
    LOG.info("network manager client start ..");

    String serverName = "127.0.0.1";
    int port = 8686;
    try {
      LOG.info(String.format("connect to server: %s on port: %s", serverName, port));
      Socket client = new Socket(serverName, port);
      LOG.info(String.format("connect %s success..", client.getRemoteSocketAddress()));

      OutputStream outToServer = client.getOutputStream();
      DataOutputStream out = new DataOutputStream(outToServer);

      out.writeUTF("ITE-CONNECT||UserName=admin,Password=inms123456");
      InputStream inFromServer = client.getInputStream();
      DataInputStream in = new DataInputStream(inFromServer);

      System.out.println("Server says: " + in.readUTF());
      client.close();
    } catch (IOException e) {
      e.printStackTrace();
    }

  }
}
