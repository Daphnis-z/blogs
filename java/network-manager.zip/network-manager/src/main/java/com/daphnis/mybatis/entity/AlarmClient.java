package com.daphnis.mybatis.entity;

public class AlarmClient {

  private String clearKeyword;
  private String clientAddress;
  private String cleared;
  private String sendTime;

  public AlarmClient(String clearKeyword, String clientAddress, String cleared,
      String sendTime) {
    this.clearKeyword = clearKeyword;
    this.clientAddress = clientAddress;
    this.cleared = cleared;
    this.sendTime = sendTime;
  }

  public String getClearKeyword() {
    return clearKeyword;
  }

  public void setClearKeyword(String clearKeyword) {
    this.clearKeyword = clearKeyword;
  }

  public String getClientAddress() {
    return clientAddress;
  }

  public void setClientAddress(String clientAddress) {
    this.clientAddress = clientAddress;
  }

  public String getCleared() {
    return cleared;
  }

  public void setCleared(String cleared) {
    this.cleared = cleared;
  }

  public String getSendTime() {
    return sendTime;
  }

  public void setSendTime(String sendTime) {
    this.sendTime = sendTime;
  }
}
