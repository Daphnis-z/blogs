package com.daphnis.mybatis.entity;

public class AlarmClient {

  private String msgSerial;
  private String clientAddress;
  private String cleared;
  private String sendTime;

  public AlarmClient(String msgSerial, String clientAddress, String cleared,
      String sendTime) {
    this.msgSerial = msgSerial;
    this.clientAddress = clientAddress;
    this.cleared = cleared;
    this.sendTime = sendTime;
  }

  public String getMsgSerial() {
    return msgSerial;
  }

  public void setMsgSerial(String msgSerial) {
    this.msgSerial = msgSerial;
  }

  public String getClientAddress() {
    return clientAddress;
  }

  public void setClientAddress(String clientAddress) {
    this.clientAddress = clientAddress;
  }

  public String getCleared() {
    return cleared;
  }

  public void setCleared(String cleared) {
    this.cleared = cleared;
  }

  public String getSendTime() {
    return sendTime;
  }

  public void setSendTime(String sendTime) {
    this.sendTime = sendTime;
  }
}
