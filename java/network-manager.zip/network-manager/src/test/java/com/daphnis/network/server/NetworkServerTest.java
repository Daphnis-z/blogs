package com.daphnis.network.server;

import org.junit.Assert;
import org.junit.Test;

public class NetworkServerTest {

  @Test
  public void parseAccount() {
    String str = "ITE-CONNECT||UserName=admin,Password=inms123456";
    String[] data = str.split("\\|\\|");
    Assert.assertTrue(data.length == 2);
  }
}